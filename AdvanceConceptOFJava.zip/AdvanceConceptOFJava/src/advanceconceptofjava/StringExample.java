/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;

/**
 *
 * @author SHIVA
 */
public class StringExample {
    public static void main(String[] args) {
        StringBuffer s = new StringBuffer("hello");
        s.append("world");
        System.out.println(s);
         StringBuilder sb = new StringBuilder("hello");
         sb.append("world");
        System.out.println(sb);
        


    }
    
}
