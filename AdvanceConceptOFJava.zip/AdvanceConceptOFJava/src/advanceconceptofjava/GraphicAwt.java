/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author SHIVA
 */
public class GraphicAwt extends Frame {
    public GraphicAwt()
    {
        setVisible(true);
        setSize(500,500);
        setBackground(Color.yellow);
        setLayout(null);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent ex)
            {
                System.exit(0);
            }
});
        
    }
    public void paint(Graphics g)
    {
        g.drawString("Welcome", 100,60);
        g.drawOval(100,100,100,100);
         g.drawOval(130,130,60,60);
        g.setColor(Color.red);
        g.fillOval(300, 100, 100, 100);
        g.fillRect(300, 250, 50, 50);
        g.fillArc(100, 250, 150, 150,0, 90);
        g.drawLine(0, 70, 500,70);
        g.drawLine(200, 0, 200, 500);
        
    }
    public static void main(String[] args) {
        GraphicAwt obj = new GraphicAwt();
        
    }
   
    
}
