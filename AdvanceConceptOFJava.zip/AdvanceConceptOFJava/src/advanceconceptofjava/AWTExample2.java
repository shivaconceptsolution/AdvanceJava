/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


/**
 *
 * @author SHIVA
 */
public class AWTExample2 extends Frame {
    Label lbl1,lbl2,lbl3;
    Button btn;
    TextField txt1,txt2;
    public AWTExample2()
    {
        setVisible(true);
        setSize(500,500);
        setLayout(null);
        setBackground(Color.yellow);
        lbl1 = new Label("Enter First Number");
        lbl1.setBounds(100, 30, 100, 30);
        add(lbl1);
        txt1 = new TextField();
        txt1.setBounds(250, 30, 100, 30);
        add(txt1);
         lbl2 = new Label("Enter Second Number");
        lbl2.setBounds(100, 70, 100, 30);
        add(lbl2);
        txt2 = new TextField();
        txt2.setBounds(250, 70, 100, 30);
        add(txt2);
        btn = new Button("CLICK");
        btn.setBounds(250, 120, 100, 30);
        add(btn);
        lbl3 = new Label();
        lbl3.setBounds(100, 200, 100, 30);
        add(lbl3);
        btn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               int a = Integer.parseInt(txt1.getText());
               int b = Integer.parseInt(txt2.getText());
               int c=a+b;
               lbl3.setText("result "+c);
            }
        });
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent ex)
            {
                System.exit(0);
            }
            
});
        
        
    }
    public static void main(String[] args) {
        AWTExample2 obj = new AWTExample2();
    }
    
}
