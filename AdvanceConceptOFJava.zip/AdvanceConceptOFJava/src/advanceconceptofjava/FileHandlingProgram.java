/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
/**
 *
 * @author SHIVA
 */
public class FileHandlingProgram {
    File f;
    FileOutputStream fw;
    FileInputStream fr;
    void createFile() throws IOException
    {
            f= new File("e://abc.txt");
            if(!f.exists())
            f.createNewFile();
            
        
    }
    void writeFile() throws IOException
    {
        
        fw = new FileOutputStream(f);
        InputStreamReader ir = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(ir);
        System.out.println("Enter data ");
        String s = br.readLine();
        byte arr[] = s.getBytes();
        fw.write(arr);
        fw.close();
        
    }
    void appendFile() throws IOException
    {
        
        fw = new FileOutputStream(f,true);
       InputStreamReader ir = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(ir);
        System.out.println("Enter data ");
        String s = br.readLine();
        byte arr[] = s.getBytes();
        fw.write(arr);
        fw.close();
        
    }
    void readFile() throws IOException
    {
        fr = new FileInputStream(f);
        byte arr[] = new byte[1000];
        int s=0,s1=0;
        while((s1=fr.read(arr))!=-1)
        {
            System.out.println(new String(arr));
                    
        }
      
        fr.close();
        
    }
    void deleteFileData() throws IOException
    {
         fw = new FileOutputStream(f);
         String s="";
         
         fw.write(s.getBytes());
         fw.close();
                 
        
    }
    void removeFile() throws IOException
    {
        
        if(Files.deleteIfExists(Paths.get("e://abc.txt")))
        {
            System.out.println("File Deleted Successfully");
        }
       
    }
    public static void main(String[] args) throws IOException {
        FileHandlingProgram obj = new FileHandlingProgram();
        obj.createFile();
       // obj.appendFile();
        
      //  obj.deleteFileData();
        //obj.removeFile();
        obj.writeFile();
        obj.readFile();
        
    }
    
}
