/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;

/**
 *
 * @author SHIVA
 */

class Table
{
    
     
     public void displayTable(int num)
    {
        synchronized(this)
        {
        for (int i = 1; i <= 10; i++) {
            try
            {
            System.out.println(num*i); 
            //wait(1000);
            
            Thread.sleep(1000);
            notify();
            }
            catch(Exception ex)
            {
                
            }
        }
            System.out.println("hello");
            System.out.println("welcome");
        }
    }
}
class Thread1 extends Thread
{
   Table t;
   Thread1(Table t)
   {
       this.t=t;
   }
   public void run()
   {
       t.displayTable(5);
   }
}
class Thread2 extends Thread
{
    Table t;

    public Thread2(Table t) {
        this.t=t;
    }
    public void run()
   {
       t.displayTable(9);
   }
    
}

public class ThreadExample22  {
    public static void main(String[] args) {
        Table t = new Table();
        Thread1 t1 = new Thread1(t);
        t1.start();
        
        Thread2 t2 = new Thread2(t);
        t2.start();
    }
    
}
