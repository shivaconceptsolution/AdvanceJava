/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;
import java.io.*;
/**
 *
 * @author SHIVA
 */
public class SerializationExample {
    public static void main(String[] args) throws IOException,ClassNotFoundException {
        File f = new File("E://demo1.txt");
        Student s = new Student(1001,"manish",45000);
        FileOutputStream fo = new FileOutputStream(f);
        ObjectOutputStream oo = new ObjectOutputStream(fo);
        oo.writeObject(s);
        oo.close();
        fo.close();
        Student s1 = null;
        FileInputStream fi = new FileInputStream(f);
        ObjectInputStream oi = new ObjectInputStream(fi);
         s1 = (Student)oi.readObject();
         System.out.println(s1.rno+" "+s1.sname+s1.fee);
        
        
    }
    
}
