/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;
import java.awt.*;
import java.awt.event.*;

public class AWTExample1 extends Frame {

    Label lbl;
    Button btn;
    
    public AWTExample1()  {
        setVisible(true);
        setSize(500,500);
        setLayout(null);
        setBackground(Color.yellow);
        lbl= new Label("Hello World");
        lbl.setBounds(100,30,150, 30);  //x,y,width,height
        add(lbl);
        btn = new Button("click");
        btn.setBounds(100,80,100,30);
        add(btn);
        addWindowListener(new WindowAdapter() {
            
            public void windowClosing(WindowEvent ex)
            {
                System.exit(0);
            }
           });
        
        
        
    }
    public static void main(String[] args) {
        AWTExample1 obj = new AWTExample1();
    }
    
    
    
}
