/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;

/**
 *
 * @author SHIVA
 */
public class ThreadExample extends Thread {
    public void run()
    {
        for (int i = 1; i <= 10; i++) {
            try
            {
            System.out.println("Process "+i + Thread.currentThread().getName());
            Thread.sleep(1000);  //interruption state
            }
            catch(InterruptedException ex)
            {
                
            }
        }
    }
    public static void main(String[] args) throws InterruptedException {
        ThreadExample obj = new ThreadExample();  //init state
        obj.start(); //runnable state
       // obj.yield();
        obj.setPriority(5);
        
        ThreadExample obj1 = new ThreadExample();  //init state
        obj1.start(); //runnable state
        obj1.setPriority(1);
    }
    
}
