/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;

import java.io.Serializable;

/**
 *
 * @author SHIVA
 */
public class Student implements Serializable{
     public int rno;
    public String sname;
    public transient int fee;
    Student(int rno,String sname,int fee)
    {
        this.rno=rno;
        this.sname=sname;
        this.fee=fee;
    }
    
}
