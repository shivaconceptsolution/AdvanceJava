/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanceconceptofjava;
import java.awt.Color;
import java.awt.Container;
import java.awt.HeadlessException;
import javax.swing.*;
/**
 *
 * @author SHIVA
 */
public class SwingBasic extends JFrame {

    JLabel lbl;
    public SwingBasic() 
    {
        setVisible(true);
        setSize(400,400);
        setLayout(null);
        Container c = getContentPane();
        c.setBackground(Color.orange);
        lbl = new JLabel("Hello World");
        lbl.setBounds(100, 50, 100,30);
        add(lbl);
        
   }
    public static void main(String[] args) {
        SwingBasic obj = new SwingBasic();
    }
 
    
}
